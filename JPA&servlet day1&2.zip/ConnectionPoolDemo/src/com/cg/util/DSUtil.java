package com.cg.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DSUtil {

	private static Connection connection = null;

	public static Connection getConnection() {

		try {
			Context initialContext = new InitialContext();
			Context envContext = (Context) initialContext.lookup("java:comp/env");
			DataSource dataSource = (DataSource) envContext.lookup("jdbc/ConPool");

			connection = dataSource.getConnection();
		} catch (NamingException | SQLException e) {
			System.out.println(e.getMessage());
		}
		return connection;
	}
}
