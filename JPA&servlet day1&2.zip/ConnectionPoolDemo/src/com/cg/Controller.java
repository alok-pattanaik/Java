package com.cg;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.util.DSUtil;

@WebServlet("/click")
public class Controller extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		Connection connection = null;
		PreparedStatement statement = null;
		try {

			connection = DSUtil.getConnection();
			statement = connection.prepareStatement("select vehicle_name,model from vehicle_master");
			ResultSet resultSet = statement.executeQuery();

			PrintWriter out = resp.getWriter();
			out.println("<html><body>");

			while (resultSet.next()) {
				out.print(resultSet.getString(1) + ":" + resultSet.getString(2) + "<br>");
			}
			out.println("</body></html>");

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

	}
}
