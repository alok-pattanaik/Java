package com.cg.utility;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.cg.exceptions.EMSException;

import oracle.jdbc.OracleDriver;

public class JdbcUtility {

	static Connection connection = null;

	public static Connection getConnection() throws EMSException {

		Driver driver = new OracleDriver();
		try {
			DriverManager.registerDriver(driver);
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "Capgemini123");
		} catch (SQLException e) {
			throw new EMSException("DB error occured");
		}
		return connection;
	}

}
