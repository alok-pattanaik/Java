package com.cg.dao;

import com.cg.exceptions.EMSException;
import com.cg.model.Employee;

public interface IEmployeeDAO {

	public int addEmployee(Employee employee) throws EMSException;
}
