package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dao.EmployeeDAO;
import com.cg.dao.IEmployeeDAO;
import com.cg.exceptions.EMSException;
import com.cg.model.Employee;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter out = response.getWriter();

		IEmployeeDAO employeeDAO = new EmployeeDAO();

		String name = request.getParameter("empname");
		String designation = request.getParameter("desig");
		String dateOfJoining = request.getParameter("doj");
		
		Date date = Date.valueOf(dateOfJoining);
		
		
		double salary = Double.parseDouble(request.getParameter("salary"));
		String city = request.getParameter("city");

		Employee employee = new Employee(name, designation, date, salary, city);
		int result = 0;

		try {
			result = employeeDAO.addEmployee(employee);

			if (result > 0) {
				out.println(result + " records inserted..");
			} else {
				out.println("problem occures while insertion");
			}

		} catch (EMSException e) {
			System.out.println(e.getMessage());
		}

	}

}
