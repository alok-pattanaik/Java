package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter out = response.getWriter();

		String name = request.getParameter("uname");
		String sex = request.getParameter("gender");
		String languages[] = request.getParameterValues("lang");

		StringBuilder builder = new StringBuilder();

		for (String lang : languages) {
			builder.append(lang).append(",");
		}
		builder.deleteCharAt(builder.length() - 1);
		String lang = builder.toString();

		String myCity = request.getParameter("city");
		String feedback = request.getParameter("feedback");

		out.println("<html><body><div align='center'>");

		out.println("<font color='#901267'>name is: " + name + "</font><br>");
		out.println("<font color='#332255'>Gender : " + sex + "</font><br>");
		out.println("<font color='#990044'>Languages known : " + lang + "</font><br>");
		out.println("<font color='#897867'>city is: " + myCity + "</font><br>");
		out.println("<font color='#TTEEQQ'>feedback submitted as: " + feedback + "</font><br>");

		out.println("</div></body></html>");

	}

}
