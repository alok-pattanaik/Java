package com.cg.dao;

import java.util.List;

import com.cg.model.Employee;

public interface IEmployeeDAO {

	public int addEmployee(Employee employee);

	public Employee getEmployee(int id);

	public int deleteEmployee(int id);

	public Employee updateEmployee(Employee employee);

	// JPQL
	public List<Employee> getEmployees();

	public List<Employee> getEmployeesByDesignation(String designation);

	public List<String> getEmployeesonCity(String city);
	
	public List<Employee> getEmployeeNameandDesig(String city);
	
	public List<Employee> getEmployeeNameandDesigByNamedQuery(String city);

}















