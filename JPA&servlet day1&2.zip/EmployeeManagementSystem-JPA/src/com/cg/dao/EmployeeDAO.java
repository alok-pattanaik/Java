package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.model.Employee;
import com.cg.util.JPAUtility;

import oracle.net.aso.q;

public class EmployeeDAO implements IEmployeeDAO {

	EntityManagerFactory factory = null;
	EntityManager manager = null;
	EntityTransaction transaction = null;

	@Override
	public int addEmployee(Employee employee) {

		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
		transaction.begin();
		try {
			manager.persist(employee);
			transaction.commit();
		} catch (PersistenceException e) {
			transaction.rollback();
			System.out.println(e.getMessage());
		} finally {
			manager.close();
			factory.close();
		}
		return employee.getId();
	}

	@Override
	public Employee getEmployee(int id) {

		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();

		Employee employee = null;

		try {
			employee = manager.find(Employee.class, id);
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
		return employee;
	}

	@Override
	public int deleteEmployee(int id) {

		int i = 0;
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
		transaction.begin();

		Employee employee = null;
		try {
			employee = manager.find(Employee.class, id);
			manager.remove(employee);
			transaction.commit();
			i++;
		} catch (Exception e) {
			transaction.rollback();
			System.out.println(e.getMessage());
		}
		return i;
	}

	@Override
	public Employee updateEmployee(Employee employee) {

		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();

		transaction.begin();

		Employee employeeInfo = manager.find(Employee.class, employee.getId());
		employeeInfo.setDesignation(employee.getDesignation());
		employeeInfo.setSalary(employee.getSalary());

		transaction.commit();

		/*
		 * manager.merge(employee); transaction.commit();
		 */

		return employeeInfo;
	}

	// JPQL concepts

	@Override
	public List<Employee> getEmployees() {

		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();

		final String selectQuery = "select e from Employee e";

		/*
		 * Query query = manager.createQuery(selectQuery); List<Employee> list =
		 * query.getResultList();
		 */

		TypedQuery<Employee> query = manager.createQuery(selectQuery, Employee.class);
		List<Employee> list = query.getResultList();
		return list;
	}

	@Override
	public List<Employee> getEmployeesByDesignation(String designation) {

		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();

		// by using parameter(?)
		/*
		 * String selectQuery = "select e from Employee e where e.designation=?";
		 * TypedQuery<Employee> query = manager.createQuery(selectQuery,
		 * Employee.class); query.setParameter(1, designation);
		 */

		// by using label
		String selectQuery = "select e from Employee e where e.designation=:desig";
		TypedQuery<Employee> query = manager.createQuery(selectQuery, Employee.class);
		query.setParameter("desig", designation);

		List<Employee> list = query.getResultList();
		return list;
	}

	@Override
	public List<String> getEmployeesonCity(String city) {

		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();

		Query query = manager.createQuery("select e.name from Employee e where e.city=?");
		query.setParameter(1, city);
		List<String> list = query.getResultList();

		return list;
	}

	@Override
	public List<Employee> getEmployeeNameandDesig(String city) {
		
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();

		Query query = manager.createQuery("select e.name,e.designation from Employee e where e.city=?");
		query.setParameter(1, city);
		List<Employee> list = query.getResultList();
		return list;
	}

	@Override
	public List<Employee> getEmployeeNameandDesigByNamedQuery(String city) {
		
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();

		Query query = manager.createNamedQuery("textQuery");
		query.setParameter(1, city);
		List<Employee> list = query.getResultList();
		return list;
	}
	
}














