package com.cg.presentation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.dao.EmployeeDAO;
import com.cg.dao.IEmployeeDAO;
import com.cg.model.Employee;

public class Client {

	public static void main(String[] args) {

		IEmployeeDAO employeeDAO = new EmployeeDAO();

		Scanner scanner = new Scanner(System.in);
		
		List<Employee> list = employeeDAO.getEmployeeNameandDesigByNamedQuery("Hyderabad");
		
		Iterator iterator = list.iterator();
		while(iterator.hasNext()) {
			Object array[] = (Object[])iterator.next();
			System.out.println(array[0] + "===" + array[1]);
		}
		
		//to get name and desig based on city - JPQL
		/*List<Employee> list = employeeDAO.getEmployeeNameandDesig("Hyderabad");
		
		Iterator iterator = list.iterator();
		while(iterator.hasNext()) {
			Object array[] = (Object[])iterator.next();
			System.out.println(array[0] + "===" + array[1]);
		}*/

		
		
		//employees based on city
		/*List<String> list = employeeDAO.getEmployeesonCity("Hyderabad");
		Iterator<String> iterator = list.iterator();
		while (iterator.hasNext()) {
			String name = iterator.next();
			System.out.println("name is: " + name);
		}*/

		//employees based on designation
		/*System.out.println("Enter desig");
		String desig = scanner.next();
		
		List<Employee> list = employeeDAO.getEmployeesByDesignation(desig);
		for (Employee employee : list) {
			System.out.println(employee);
		}*/
		
		
		//JPQl - select all data
		/*List<Employee> list = employeeDAO.getEmployees();
		for(Employee employee : list) {
			System.out.println(employee);
		}*/
		
		
		
		
		//update operation
		/*System.out.println("enter id");
		int id = scanner.nextInt();
		System.out.println("enter salary");
		double salary = scanner.nextDouble();
		System.out.println("desig:");
		String desig = scanner.next();

		Employee employee = new Employee(id, salary, desig);

		Employee updatedEmployee = employeeDAO.updateEmployee(employee);
		System.out.println(updatedEmployee);*/
		
		
		
		//delete one employee
		/*System.out.println("enter id to delete");
		int id = scanner.nextInt();

		int i = employeeDAO.deleteEmployee(id);
		if (i > 0) {
			System.out.println("record deleted");
		}
*/		
		
		//fetch by using find() method
		/*
		 
			System.out.println("enetr id to search");
			int id = scanner.nextInt();
			Employee employee = employeeDAO.getEmployee(id);
			System.out.println(employee);
		*/
		
		
		//inserting one employee
		/*System.out.println("Enter name");
		String name = scanner.next();

		System.out.println("enter salary");
		double salary = scanner.nextDouble();

		System.out.println("enter designation");
		String desig = scanner.next();

		System.out.println("Enter Joining date");
		String date = scanner.next();
		Date joinDate = null;

		SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
		try {
			joinDate = format.parse(date);
		} catch (ParseException e) {
			System.out.println(e.getMessage());
		}

		System.out.println("city");
		String city = scanner.next();

		Employee employee = new Employee(name, salary, desig, joinDate, city);

		int id = employeeDAO.addEmployee(employee);
		System.out.println("employee has inserted with the id: " + id);*/
	}

}
