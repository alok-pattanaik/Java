package com.cg.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "pune_intern_batch")
@NamedQuery(query = "select e.name,e.designation from Employee e where e.city=?", 
	name = "textQuery")
/*@NamedQueries({
	@NamedQuery(name="",query=""),
	@NamedQuery(name="",query="")
})*/
public class Employee {

	@Id
	@GeneratedValue
	@Column(name = "emp_id")
	private int id;

	@Column(name = "emp_name")
	private String name;
	private double salary;
	private String designation;

	@Column(name = "joining_date")
	@Temporal(TemporalType.DATE)
	private Date joinDate;

	private String city;

	public Employee() {
		// TODO Auto-generated constructor stub
	}

	public Employee(int id, double salary, String designation) {
		super();
		this.id = id;
		this.salary = salary;
		this.designation = designation;
	}

	public Employee(String name, double salary, String designation, Date joinDate, String city) {
		super();
		this.name = name;
		this.salary = salary;
		this.designation = designation;
		this.joinDate = joinDate;
		this.city = city;
	}

	public Employee(int id, String name, double salary, String designation, Date joinDate, String city) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.designation = designation;
		this.joinDate = joinDate;
		this.city = city;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public Date getJoinDate() {
		return joinDate;
	}

	public void setJoinDate(Date joinDate) {
		this.joinDate = joinDate;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + ", designation=" + designation
				+ ", joinDate=" + joinDate + ", city=" + city + "]";
	}

}
