package com.cg;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;

public class Client {

	public static void main(String[] args) {

		EntityManagerFactory factory = Persistence.createEntityManagerFactory("product_bu");
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();

		Product product = new Product(); //new state or transient state
		//product.setId(102);
		product.setName("shoes");
		product.setCost(5000);
		product.setUnits(12);
		product.setCompany("Fossil");

		transaction.begin();

		try {
			manager.persist(product); // is used to persist object into DB table  //managed or persistance state
			transaction.commit();
		} catch (PersistenceException e) {
			System.out.println(e.getMessage());
			transaction.rollback();
		}

		manager.close();
		factory.close();

		System.out.println("done..");

	}

}
