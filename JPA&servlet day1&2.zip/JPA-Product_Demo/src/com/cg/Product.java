package com.cg;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "product_master")
public class Product {

	@Id
	@SequenceGenerator(name="myseq",sequenceName="intern_seq")
	@GeneratedValue(generator="myseq",strategy=GenerationType.SEQUENCE)
	@Column(name = "pid")
	private int id;
	private String name;
	private double cost;
	private int units;
	private String company;

	public Product() {
		// TODO Auto-generated constructor stub
	}

	public Product(int id, String name, double cost, int units, String company) {
		super();
		this.id = id;
		this.name = name;
		this.cost = cost;
		this.units = units;
		this.company = company;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

	public int getUnits() {
		return units;
	}

	public void setUnits(int units) {
		this.units = units;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", cost=" + cost + ", units=" + units + ", company=" + company
				+ "]";
	}

}
