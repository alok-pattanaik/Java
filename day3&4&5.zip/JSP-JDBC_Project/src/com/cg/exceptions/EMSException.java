package com.cg.exceptions;

public class EMSException extends Exception {

	public EMSException(String message) {
		super(message);
	}
}
