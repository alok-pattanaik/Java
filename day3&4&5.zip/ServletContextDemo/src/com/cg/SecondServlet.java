package com.cg;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oracle.jdbc.OracleDriver;

@WebServlet(urlPatterns = "/mytest", initParams = { 
		@WebInitParam(name = "author", value = "kumar"),
		@WebInitParam(name = "date", value = "2-Feb-2020"), 
		@WebInitParam(name = "location", value = "Hyderabad") })
public class SecondServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		PrintWriter out = resp.getWriter();
		ServletContext context = getServletContext();
		String dbUrl = context.getInitParameter("url");
		String dbUname = context.getInitParameter("username");
		String dbPassword = context.getInitParameter("password");
		
		ServletConfig config = getServletConfig();
		out.println("author name is: " + config.getInitParameter("author"));
		out.println("date published is: " + config.getInitParameter("date"));
		out.println("location is: " + config.getInitParameter("location"));

		try {
			DriverManager.registerDriver(new OracleDriver());
			Connection connection = DriverManager.getConnection(dbUrl, dbUname, dbPassword);
			out.println("connected to DB");

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
