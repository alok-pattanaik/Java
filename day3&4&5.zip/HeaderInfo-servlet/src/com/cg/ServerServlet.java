package com.cg;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/server")
public class ServerServlet extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		PrintWriter out = resp.getWriter();
		out.println("<html><body>");
		out.println(req.getServerName() + "<br>");
		out.println(req.getServerPort() + "<br>");
		out.println(req.getLocalPort() + "<br>");
		out.println(req.getQueryString() + "<br>");
		out.println(req.getRemoteUser() + "<br>");
		out.println(req.getLocalName() + "<br>");
		out.println(req.getLocalAddr() + "<br>");
		
	}
}
