package com.cg.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		PrintWriter writer = resp.getWriter();

		String username = req.getParameter("uname");
		String password = req.getParameter("pass");

		writer.println("<html><body>");

		RequestDispatcher dispatcher = null;

		if ("admin".equalsIgnoreCase(username) && "admin".equals(password)) {
			dispatcher = req.getRequestDispatcher("success");
			dispatcher.forward(req, resp);
		} else {
			writer.println("<h1><font color='red'>Invalid credentials, try again </font></h1>");
			dispatcher = req.getRequestDispatcher("login.html");
			dispatcher.include(req, resp);
		}

		writer.println("</body></html>");

	}
}
