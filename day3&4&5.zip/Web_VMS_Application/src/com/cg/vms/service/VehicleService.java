package com.cg.vms.service;

import java.util.List;

import com.cg.vms.dao.IVehicleDao;
import com.cg.vms.dao.VehicleDao;
import com.cg.vms.exceptions.VMSException;
import com.cg.vms.model.Vehicle;

public class VehicleService implements IVehicleService {

	IVehicleDao vehicelDao = new VehicleDao();

	@Override
	public int addVehicle(Vehicle vehicle) throws VMSException {
		return vehicelDao.addVehicle(vehicle);
	}

	@Override
	public List<Vehicle> getVehicles() throws VMSException {
		return vehicelDao.getVehicles();
	}

}
