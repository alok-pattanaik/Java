package com.cg.vms.service;

import java.util.List;

import com.cg.vms.exceptions.VMSException;
import com.cg.vms.model.Vehicle;

public interface IVehicleService {

	public int addVehicle(Vehicle vehicle) throws VMSException;

	public List<Vehicle> getVehicles() throws VMSException;
}
