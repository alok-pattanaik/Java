package com.cg.vms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cg.vms.exceptions.VMSException;
import com.cg.vms.model.Vehicle;
import com.cg.vms.utility.JdbcUtility;

public class VehicleDao implements IVehicleDao {

	Connection connection = null;
	PreparedStatement statement = null;
	ResultSet resultSet = null;

	@Override
	public int addVehicle(Vehicle vehicle) throws VMSException {

		connection = JdbcUtility.getConnection();
		int generatedId = 0;
		try {
			statement = connection.prepareStatement(QueryConstants.ADD_VEHICLE_QUERY);
			statement.setString(1, vehicle.getName());
			statement.setString(2, vehicle.getModel());
			statement.setDouble(3, vehicle.getCost());

			LocalDate date = vehicle.getDate();
			Date mfgDate = Date.valueOf(date);
			statement.setDate(4, mfgDate);

			statement.executeUpdate();

			statement = connection.prepareStatement(QueryConstants.GENERATED_SEQ_ID);
			resultSet = statement.executeQuery();

			resultSet.next();

			generatedId = resultSet.getInt(1);

		} catch (SQLException e) {
			throw new VMSException("problem while creating PS object");
		} finally {
			try {
				resultSet.close();
				statement.close();
				connection.close();
			} catch (SQLException e) {
				throw new VMSException("problem while closing");
			}

		}

		return generatedId;
	}

	@Override
	public List<Vehicle> getVehicles() throws VMSException {

		List<Vehicle> list = new ArrayList<>();
		connection = JdbcUtility.getConnection();
		try {
			statement = connection.prepareStatement(QueryConstants.GET_VEHICLES_QUERY);
			resultSet = statement.executeQuery();

			while (resultSet.next()) {
				int id = resultSet.getInt(1);
				String name = resultSet.getString(2);
				String model = resultSet.getString(3);
				double cost = resultSet.getDouble(4);
				Date date = resultSet.getDate(5);

				LocalDate mfgdate = date.toLocalDate();
				Vehicle vehicle = new Vehicle(id, name, model, cost, mfgdate);
				list.add(vehicle);
			}

		} catch (SQLException e) {
			throw new VMSException("problem while creating PS object");
		} finally {
			try {
				resultSet.close();
				statement.close();
				connection.close();
			} catch (SQLException e) {
				throw new VMSException("problem while closing");
			}

		}
		return list;
	}

}
