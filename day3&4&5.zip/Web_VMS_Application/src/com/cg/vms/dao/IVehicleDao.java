package com.cg.vms.dao;

import java.util.List;

import com.cg.vms.exceptions.VMSException;
import com.cg.vms.model.Vehicle;

public interface IVehicleDao {

	public int addVehicle(Vehicle vehicle) throws VMSException;
	
	public List<Vehicle> getVehicles() throws VMSException;
}
