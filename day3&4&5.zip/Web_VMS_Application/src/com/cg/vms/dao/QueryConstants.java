package com.cg.vms.dao;

public interface QueryConstants {

	String ADD_VEHICLE_QUERY = "INSERT INTO vehicle_master VALUES(HIBERNATE_SEQUENCE.NEXTVAL,?,?,?,?)";
	
	String GENERATED_SEQ_ID = "SELECT HIBERNATE_SEQUENCE.CURRVAL FROM DUAL";
	
	String GET_VEHICLES_QUERY=  "SELECT *FROM vehicle_master";
}
