package com.cg.vms.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.vms.exceptions.VMSException;
import com.cg.vms.model.Vehicle;
import com.cg.vms.service.IVehicleService;
import com.cg.vms.service.VehicleService;

@WebServlet("/vehicleRegister")
public class VehicleController extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		IVehicleService service = new VehicleService();
		int genId = 0;

		String name = request.getParameter("vname");
		String model = request.getParameter("model");
		double cost = Double.parseDouble(request.getParameter("cost"));
		String date = request.getParameter("date");

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate mfgDate = LocalDate.parse(date, formatter);

		Vehicle vehicle = new Vehicle(name, model, cost, mfgDate);

		try {
			genId = service.addVehicle(vehicle);
			request.setAttribute("message", genId);

			request.getRequestDispatcher("success.jsp").forward(request, response);

		} catch (VMSException e) {
			request.setAttribute("message", e.getMessage());
			request.getRequestDispatcher("error.jsp").forward(request, response);
		}

	}
}
