package com.cg.vms.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.vms.exceptions.VMSException;
import com.cg.vms.model.Vehicle;
import com.cg.vms.service.IVehicleService;
import com.cg.vms.service.VehicleService;

@WebServlet("/seeVehicles")
public class GetVehiclesController extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		IVehicleService service = new VehicleService();
		try {
			List<Vehicle> list = service.getVehicles();
			request.setAttribute("message", list);
			request.getRequestDispatcher("vehiclesList.jsp").forward(request, response);
		} catch (VMSException e) {
			request.setAttribute("message", e.getMessage());
			request.getRequestDispatcher("error.jsp").forward(request, response);
		}

	}
}
