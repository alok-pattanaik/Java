package com.cg.vms.utility;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.vms.exceptions.VMSException;

public class JdbcUtility {

	private static Connection connection = null;

	public static Connection getConnection() throws VMSException {

		try {
			Context context = new InitialContext();
			Context envContext = (Context) context.lookup("java:comp/env");
			DataSource dataSource = (DataSource) envContext.lookup("jdbc/myConnPool");
			connection = dataSource.getConnection();
		} catch (NamingException | SQLException e) {
			throw new VMSException("Problem occured from DB");
		}
		return connection;
	}
}
