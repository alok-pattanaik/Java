package com.cg.vms.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;

public class Vehicle implements Serializable {

	private Integer id;
	private String name;
	private String model;
	private Double cost;
	private LocalDate date;

	public Vehicle() {
		// TODO Auto-generated constructor stub
	}

	public Vehicle(Integer id, String name, String model, Double cost, LocalDate date) {
		super();
		this.id = id;
		this.name = name;
		this.model = model;
		this.cost = cost;
		this.date = date;
	}

	public Vehicle(String name, String model, Double cost, LocalDate date) {
		super();
		this.name = name;
		this.model = model;
		this.cost = cost;
		this.date = date;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public Double getCost() {
		return cost;
	}

	public void setCost(Double cost) {
		this.cost = cost;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "Vehicle [id=" + id + ", name=" + name + ", model=" + model + ", cost=" + cost + ", date=" + date + "]";
	}

}
